<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Support\\Providers\\MySQLScoutServiceProvider',
    1 => 'Modules\\Support\\Providers\\EloquentMacroServiceProvider',
    2 => 'Modules\\Support\\Providers\\PWAServiceProvider',
    3 => 'Modules\\Support\\Providers\\SitemapServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Support\\Providers\\MySQLScoutServiceProvider',
    1 => 'Modules\\Support\\Providers\\EloquentMacroServiceProvider',
    2 => 'Modules\\Support\\Providers\\PWAServiceProvider',
    3 => 'Modules\\Support\\Providers\\SitemapServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);