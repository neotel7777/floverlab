<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Core\\Providers\\CoreServiceProvider',
    1 => 'Modules\\Core\\Providers\\ModuleServiceProvider',
    2 => 'Modules\\Core\\Providers\\SearchEngineServiceProvider',
    3 => 'Modules\\Core\\Providers\\RouteServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Core\\Providers\\CoreServiceProvider',
    1 => 'Modules\\Core\\Providers\\ModuleServiceProvider',
    2 => 'Modules\\Core\\Providers\\SearchEngineServiceProvider',
    3 => 'Modules\\Core\\Providers\\RouteServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);