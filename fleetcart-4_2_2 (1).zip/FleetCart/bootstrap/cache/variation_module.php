<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Variation\\Providers\\VariationServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Variation\\Providers\\VariationServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);