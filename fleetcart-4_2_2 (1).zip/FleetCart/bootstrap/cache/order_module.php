<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Order\\Providers\\OrderServiceProvider',
    1 => 'Modules\\Order\\Providers\\EventServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Order\\Providers\\OrderServiceProvider',
    1 => 'Modules\\Order\\Providers\\EventServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);