<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Import\\Providers\\ImportServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Import\\Providers\\ImportServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);