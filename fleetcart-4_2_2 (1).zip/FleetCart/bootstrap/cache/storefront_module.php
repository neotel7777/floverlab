<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Storefront\\Providers\\StorefrontServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Storefront\\Providers\\StorefrontServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);