<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Menu\\Providers\\MenuServiceProvider',
    1 => 'Modules\\Menu\\Providers\\EventServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Menu\\Providers\\MenuServiceProvider',
    1 => 'Modules\\Menu\\Providers\\EventServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);