<?php

namespace FleetCart;

class FleetCart
{
    /**
     * The FleetCart version.
     *
     * @var string
     */
    const VERSION = '4.2.2';

    /**
     * The Envato item ID.
     *
     * @var string
     */
    const ITEM_ID = '23014826';
}
