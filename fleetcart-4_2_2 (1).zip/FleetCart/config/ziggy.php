<?php

return [
    'only' => [
      //
    ],
    'except' => [
        'install.*',
        'license.*',
        'debugbar.*',
        'clockwork.*',
        'horizon.*',
        'passport.*',
        'telescope',
        'telescope.*',
        'impersonate.*',
        'ignition.*',
    ],
];
