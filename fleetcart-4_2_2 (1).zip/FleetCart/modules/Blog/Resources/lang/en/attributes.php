<?php

return [
    'posts' => [
        'title' => 'Title',
        'description' => 'Description',
        'slug' => 'URL',
        'category' => 'Select Category',
        'tags' => 'Add Tags',
        'publish_status' => 'Publish Status',
    ],
    'categories' => [
        'name' => 'Name',
        'slug' => 'URL',
    ],
    'tags' => [
        'name' => 'Name',
        'slug' => 'URL',
    ],
];
