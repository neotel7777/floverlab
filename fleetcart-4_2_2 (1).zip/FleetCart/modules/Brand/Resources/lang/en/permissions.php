<?php

return [
    'index' => 'Index Test',
    'create' => 'Create Test',
    'edit' => 'Edit Test',
    'destroy' => 'Delete Test',
];
