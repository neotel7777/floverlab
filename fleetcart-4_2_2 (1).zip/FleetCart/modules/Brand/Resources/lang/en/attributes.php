<?php

return [
    'name' => 'Name',
    'is_active' => 'Status',
];
