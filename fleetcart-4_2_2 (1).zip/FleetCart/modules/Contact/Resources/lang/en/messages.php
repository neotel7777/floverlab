<?php

return [
    'your_message_has_been_sent' => 'Your message has been sent',
];
