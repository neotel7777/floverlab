<?php

return [
    'failed_to_verify' => 'Failed to verify',
];
