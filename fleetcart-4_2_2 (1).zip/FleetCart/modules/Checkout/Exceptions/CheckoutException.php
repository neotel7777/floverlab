<?php

namespace Modules\Checkout\Exceptions;

use Exception;

class CheckoutException extends Exception
{

}
