<?php

return [
    'no_shipping_method' => 'No shipping method is found',
];
