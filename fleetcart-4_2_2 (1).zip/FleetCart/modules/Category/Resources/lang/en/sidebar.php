<?php

return [
    'categories' => 'Categories',
];
