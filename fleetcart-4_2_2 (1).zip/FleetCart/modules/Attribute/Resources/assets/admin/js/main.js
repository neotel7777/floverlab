import AttributeValues from "./AttributeValues";

if ($("#attribute-values-wrapper").length !== 0) {
    new AttributeValues();
}
