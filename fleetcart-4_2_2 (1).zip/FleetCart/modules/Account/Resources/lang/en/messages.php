<?php

return [
    'profile_updated' => 'Your profile has been updated',
    'default_address_updated' => 'The default address has been updated',
    'address_created' => 'The address has been created',
    'address_updated' => 'The address has been updated',
    'address_deleted' => 'The address has been deleted',
];
