<div class="world-map">
    <div class="grid-header clearfix">
        <h4><i class="fa fa-globe" aria-hidden="true"></i>World Map</h4>
    </div>

    <div id="world-map" style="width: 600px; height: 305px;"></div>
</div>
