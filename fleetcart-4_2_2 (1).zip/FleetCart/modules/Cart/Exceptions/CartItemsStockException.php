<?php

namespace Modules\Cart\Exceptions;

use Exception;

class CartItemsStockException extends Exception
{

}
