<?php

header('Location: public');
